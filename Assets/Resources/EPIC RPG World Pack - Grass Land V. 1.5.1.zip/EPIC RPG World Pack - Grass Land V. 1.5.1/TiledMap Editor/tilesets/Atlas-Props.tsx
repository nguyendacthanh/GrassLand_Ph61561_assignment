<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Atlas-Props" tilewidth="32" tileheight="32" tilecount="2652" columns="39">
 <image source="../../Props/Atlas-Props.png" width="1248" height="2176"/>
</tileset>
