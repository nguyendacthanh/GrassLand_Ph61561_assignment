<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Atlas-Props-Sprites" tilewidth="448" tileheight="320" tilecount="748" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="1449">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/barrels_0.png"/>
 </tile>
 <tile id="1450">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/barrels_1.png"/>
 </tile>
 <tile id="1451">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/barrels_2.png"/>
 </tile>
 <tile id="1452">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/barrels_3.png"/>
 </tile>
 <tile id="1453">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/barrels_4.png"/>
 </tile>
 <tile id="1454">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/barrels_5.png"/>
 </tile>
 <tile id="1455">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/barrels_6.png"/>
 </tile>
 <tile id="1456">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/barrels_7.png"/>
 </tile>
 <tile id="1457">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/barrels_8.png"/>
 </tile>
 <tile id="1458">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/barrels_9.png"/>
 </tile>
 <tile id="1459">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/barrels_10.png"/>
 </tile>
 <tile id="1460">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/barrels_11.png"/>
 </tile>
 <tile id="1461">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/barrels_12.png"/>
 </tile>
 <tile id="1462">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/barrels_13.png"/>
 </tile>
 <tile id="1463">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/barrels_14.png"/>
 </tile>
 <tile id="1464">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/barrels_15.png"/>
 </tile>
 <tile id="1465">
  <image width="160" height="288" source="../../Props/Atlas-Props-individual sprites/blacksmith as a simple house.png"/>
 </tile>
 <tile id="1466">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/blacksmith props_0.png"/>
 </tile>
 <tile id="1467">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/blacksmith props_1.png"/>
 </tile>
 <tile id="1468">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/blacksmith props_2.png"/>
 </tile>
 <tile id="1469">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/blacksmith props_3.png"/>
 </tile>
 <tile id="1470">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/blacksmith props_4.png"/>
 </tile>
 <tile id="1471">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/blacksmith props_5.png"/>
 </tile>
 <tile id="1472">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/blacksmith props_6.png"/>
 </tile>
 <tile id="1473">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/blacksmith props_7.png"/>
 </tile>
 <tile id="1474">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/blacksmith props_8.png"/>
 </tile>
 <tile id="1475">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/blacksmith props_9.png"/>
 </tile>
 <tile id="1476">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/blacksmith props_10.png"/>
 </tile>
 <tile id="1477">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/blacksmith props_11.png"/>
 </tile>
 <tile id="1478">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/blacksmith props_12.png"/>
 </tile>
 <tile id="1479">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/blacksmith props_13.png"/>
 </tile>
 <tile id="1480">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/blacksmith props_14.png"/>
 </tile>
 <tile id="1481">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/blacksmith props_15.png"/>
 </tile>
 <tile id="1482">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/blacksmith props_16.png"/>
 </tile>
 <tile id="1483">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/blacksmith props_17.png"/>
 </tile>
 <tile id="1484">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/blacksmith props_18.png"/>
 </tile>
 <tile id="1485">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/blacksmith props_19.png"/>
 </tile>
 <tile id="1486">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/blacksmith props_20.png"/>
 </tile>
 <tile id="1487">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/blacksmith props_21.png"/>
 </tile>
 <tile id="1488">
  <image width="32" height="64" source="../../Props/Atlas-Props-individual sprites/blacksmith props_30.png"/>
 </tile>
 <tile id="1489">
  <image width="32" height="64" source="../../Props/Atlas-Props-individual sprites/blacksmith props_31.png"/>
 </tile>
 <tile id="1490">
  <image width="32" height="64" source="../../Props/Atlas-Props-individual sprites/blacksmith props_32.png"/>
 </tile>
 <tile id="1491">
  <image width="32" height="64" source="../../Props/Atlas-Props-individual sprites/blacksmith props_33.png"/>
 </tile>
 <tile id="1492">
  <image width="32" height="64" source="../../Props/Atlas-Props-individual sprites/blacksmith props_34.png"/>
 </tile>
 <tile id="1493">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/blacksmith props_35.png"/>
 </tile>
 <tile id="1494">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/blacksmith props_36.png"/>
 </tile>
 <tile id="1495">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/blacksmith props_37.png"/>
 </tile>
 <tile id="1496">
  <image width="64" height="160" source="../../Props/Atlas-Props-individual sprites/blacksmith props_38.png"/>
 </tile>
 <tile id="1497">
  <image width="64" height="160" source="../../Props/Atlas-Props-individual sprites/blacksmith props_39.png"/>
 </tile>
 <tile id="1498">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/blacksmith props_40.png"/>
 </tile>
 <tile id="1499">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/blacksmith props_41.png"/>
 </tile>
 <tile id="1500">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/blacksmith props_42.png"/>
 </tile>
 <tile id="1501">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/blacksmith props_43.png"/>
 </tile>
 <tile id="1502">
  <image width="320" height="128" source="../../Props/Atlas-Props-individual sprites/blacksmith shadow.png"/>
 </tile>
 <tile id="1503">
  <image width="192" height="64" source="../../Props/Atlas-Props-individual sprites/blacksmith wall1.png"/>
 </tile>
 <tile id="1504">
  <image width="32" height="64" source="../../Props/Atlas-Props-individual sprites/blacksmith wall1-tileable.png"/>
 </tile>
 <tile id="1505">
  <image width="192" height="64" source="../../Props/Atlas-Props-individual sprites/blacksmith wall2.png"/>
 </tile>
 <tile id="1506">
  <image width="32" height="64" source="../../Props/Atlas-Props-individual sprites/blacksmith wall2-tileable.png"/>
 </tile>
 <tile id="1507">
  <image width="320" height="288" source="../../Props/Atlas-Props-individual sprites/blacksmith.png"/>
 </tile>
 <tile id="1508">
  <image width="96" height="96" source="../../Props/Atlas-Props-individual sprites/blacksmith-doorway only.png"/>
 </tile>
 <tile id="1509">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/bucket_0.png"/>
 </tile>
 <tile id="1510">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/bucket_1.png"/>
 </tile>
 <tile id="1511">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/bucket_2.png"/>
 </tile>
 <tile id="1512">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/bucket_3.png"/>
 </tile>
 <tile id="1513">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/bushes_0.png"/>
 </tile>
 <tile id="1514">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/bushes_1.png"/>
 </tile>
 <tile id="1515">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/bushes_2.png"/>
 </tile>
 <tile id="1516">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/bushes_3.png"/>
 </tile>
 <tile id="1517">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/bushes_4.png"/>
 </tile>
 <tile id="1518">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/bushes_5.png"/>
 </tile>
 <tile id="1519">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/bushes_6.png"/>
 </tile>
 <tile id="1520">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/bushes_7.png"/>
 </tile>
 <tile id="1521">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/bushes_8.png"/>
 </tile>
 <tile id="1522">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/bushes_9.png"/>
 </tile>
 <tile id="1523">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/bushes_10.png"/>
 </tile>
 <tile id="1524">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/bushes_11.png"/>
 </tile>
 <tile id="1525">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/bushes_12.png"/>
 </tile>
 <tile id="1526">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/bushes_13.png"/>
 </tile>
 <tile id="1527">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/bushes_14.png"/>
 </tile>
 <tile id="1528">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/bushes_15.png"/>
 </tile>
 <tile id="1529">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/campfire and firewood_0.png"/>
 </tile>
 <tile id="1530">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/campfire and firewood_1.png"/>
 </tile>
 <tile id="1531">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/campfire and firewood_2.png"/>
 </tile>
 <tile id="1532">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/campfire and firewood_3.png"/>
 </tile>
 <tile id="1533">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/campfire and firewood_4.png"/>
 </tile>
 <tile id="1534">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/campfire and firewood_5.png"/>
 </tile>
 <tile id="1535">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chests_0.png"/>
 </tile>
 <tile id="1536">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chests_1.png"/>
 </tile>
 <tile id="1537">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chests_2.png"/>
 </tile>
 <tile id="1538">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chests_3.png"/>
 </tile>
 <tile id="1539">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chests_4.png"/>
 </tile>
 <tile id="1540">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chests_5.png"/>
 </tile>
 <tile id="1544">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/crate_0.png"/>
 </tile>
 <tile id="1545">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/crate_1.png"/>
 </tile>
 <tile id="1546">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/crate_2.png"/>
 </tile>
 <tile id="1547">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/crate_3.png"/>
 </tile>
 <tile id="1548">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/crate_4.png"/>
 </tile>
 <tile id="1549">
  <image width="32" height="64" source="../../Props/Atlas-Props-individual sprites/crate_5.png"/>
 </tile>
 <tile id="1550">
  <image width="32" height="64" source="../../Props/Atlas-Props-individual sprites/crate_6.png"/>
 </tile>
 <tile id="1551">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/crate_7.png"/>
 </tile>
 <tile id="1552">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/fences-_1.png"/>
 </tile>
 <tile id="1553">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/fences-_2.png"/>
 </tile>
 <tile id="1554">
  <image width="96" height="32" source="../../Props/Atlas-Props-individual sprites/fences-_3.png"/>
 </tile>
 <tile id="1555">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/fences-_4.png"/>
 </tile>
 <tile id="1556">
  <image width="96" height="32" source="../../Props/Atlas-Props-individual sprites/fences-_5.png"/>
 </tile>
 <tile id="1557">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/fences-_6.png"/>
 </tile>
 <tile id="1558">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/fences-_7.png"/>
 </tile>
 <tile id="1559">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/fences-_8.png"/>
 </tile>
 <tile id="1560">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/fences-_9.png"/>
 </tile>
 <tile id="1561">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/fences-_10.png"/>
 </tile>
 <tile id="1562">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/fences-_11.png"/>
 </tile>
 <tile id="1563">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/fences-_12.png"/>
 </tile>
 <tile id="1564">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/fences-_13.png"/>
 </tile>
 <tile id="1565">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/fences-_14.png"/>
 </tile>
 <tile id="1566">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/fences-_15.png"/>
 </tile>
 <tile id="1567">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/fences-_16.png"/>
 </tile>
 <tile id="1568">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/fences-_17.png"/>
 </tile>
 <tile id="1569">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/fences-_18.png"/>
 </tile>
 <tile id="1570">
  <image width="96" height="32" source="../../Props/Atlas-Props-individual sprites/fences-_19.png"/>
 </tile>
 <tile id="1571">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/fences-_20.png"/>
 </tile>
 <tile id="1572">
  <image width="96" height="32" source="../../Props/Atlas-Props-individual sprites/fences-_21.png"/>
 </tile>
 <tile id="1573">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/fences-_22.png"/>
 </tile>
 <tile id="1574">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/fences-_23.png"/>
 </tile>
 <tile id="1575">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/fences-_24.png"/>
 </tile>
 <tile id="1576">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/fences-_25.png"/>
 </tile>
 <tile id="1577">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/fences-_26.png"/>
 </tile>
 <tile id="1578">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/fences-_27.png"/>
 </tile>
 <tile id="1579">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/fences-_28.png"/>
 </tile>
 <tile id="1580">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/fences-_32.png"/>
 </tile>
 <tile id="1581">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/fences-_33.png"/>
 </tile>
 <tile id="1582">
  <image width="32" height="64" source="../../Props/Atlas-Props-individual sprites/fences-gate_29.png"/>
 </tile>
 <tile id="1583">
  <image width="32" height="64" source="../../Props/Atlas-Props-individual sprites/fences-gate_30.png"/>
 </tile>
 <tile id="1584">
  <image width="96" height="32" source="../../Props/Atlas-Props-individual sprites/fences-gate_31.png"/>
 </tile>
 <tile id="1585">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/fences-grass-_2.png"/>
 </tile>
 <tile id="1586">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/fences-grass-_3.png"/>
 </tile>
 <tile id="1587">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/fences-grass-_4.png"/>
 </tile>
 <tile id="1588">
  <image width="96" height="32" source="../../Props/Atlas-Props-individual sprites/fences-grass-_5.png"/>
 </tile>
 <tile id="1589">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/fences-grass-_6.png"/>
 </tile>
 <tile id="1590">
  <image width="96" height="32" source="../../Props/Atlas-Props-individual sprites/fences-grass-_7.png"/>
 </tile>
 <tile id="1591">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/fences-grass-_8.png"/>
 </tile>
 <tile id="1592">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/fences-grass-_9.png"/>
 </tile>
 <tile id="1593">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/fences-grass-_10.png"/>
 </tile>
 <tile id="1594">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/fences-grass-_11.png"/>
 </tile>
 <tile id="1595">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/fences-grass-_12.png"/>
 </tile>
 <tile id="1596">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/fences-grass-_13.png"/>
 </tile>
 <tile id="1597">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/fences-grass-_14.png"/>
 </tile>
 <tile id="1598">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/fences-grass-_15.png"/>
 </tile>
 <tile id="1599">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/fences-grass-_16.png"/>
 </tile>
 <tile id="1600">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/fences-grass-_17.png"/>
 </tile>
 <tile id="1601">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/fences-grass-_18.png"/>
 </tile>
 <tile id="1602">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/fences-grass-_19.png"/>
 </tile>
 <tile id="1603">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/fences-grass-_20.png"/>
 </tile>
 <tile id="1604">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/fences-grass-_21.png"/>
 </tile>
 <tile id="1605">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/fences-grass-_22.png"/>
 </tile>
 <tile id="1606">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/fences-grass-_23.png"/>
 </tile>
 <tile id="1607">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/fences-grass-_24.png"/>
 </tile>
 <tile id="1608">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/fences-grass-_25.png"/>
 </tile>
 <tile id="1609">
  <image width="96" height="32" source="../../Props/Atlas-Props-individual sprites/fences-grass-_26.png"/>
 </tile>
 <tile id="1610">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/fences-grass-_27.png"/>
 </tile>
 <tile id="1611">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/fences-grass-_28.png"/>
 </tile>
 <tile id="1612">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/fences-grass-_29.png"/>
 </tile>
 <tile id="1613">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/fences-grass-_30.png"/>
 </tile>
 <tile id="1614">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/fences-grass-_31.png"/>
 </tile>
 <tile id="1615">
  <image width="96" height="32" source="../../Props/Atlas-Props-individual sprites/fences-grass-_33.png"/>
 </tile>
 <tile id="1616">
  <image width="32" height="64" source="../../Props/Atlas-Props-individual sprites/fences-grass-gate_0.png"/>
 </tile>
 <tile id="1617">
  <image width="96" height="32" source="../../Props/Atlas-Props-individual sprites/fences-grass-gate_1.png"/>
 </tile>
 <tile id="1618">
  <image width="32" height="64" source="../../Props/Atlas-Props-individual sprites/fences-grass-gate_2.png"/>
 </tile>
 <tile id="1619">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/flowers_0.png"/>
 </tile>
 <tile id="1620">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/flowers_1.png"/>
 </tile>
 <tile id="1621">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/flowers_2.png"/>
 </tile>
 <tile id="1622">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/flowers_3.png"/>
 </tile>
 <tile id="1623">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/flowers_4.png"/>
 </tile>
 <tile id="1624">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/flowers_5.png"/>
 </tile>
 <tile id="1625">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/flowers_6.png"/>
 </tile>
 <tile id="1626">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/flowers_7.png"/>
 </tile>
 <tile id="1627">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/flowers_8.png"/>
 </tile>
 <tile id="1628">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/flowers_9.png"/>
 </tile>
 <tile id="1629">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/flowers_10.png"/>
 </tile>
 <tile id="1630">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/flowers_11.png"/>
 </tile>
 <tile id="1631">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/flowers_12.png"/>
 </tile>
 <tile id="1632">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/flowers_13.png"/>
 </tile>
 <tile id="1633">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/flowers_14.png"/>
 </tile>
 <tile id="1634">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/flowers_15.png"/>
 </tile>
 <tile id="1635">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/flowers_16.png"/>
 </tile>
 <tile id="1636">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/flowers_17.png"/>
 </tile>
 <tile id="1637">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/flowers_18.png"/>
 </tile>
 <tile id="1638">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/flowers_19.png"/>
 </tile>
 <tile id="1639">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - darker_0.png"/>
 </tile>
 <tile id="1640">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - darker_1.png"/>
 </tile>
 <tile id="1641">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - darker_2.png"/>
 </tile>
 <tile id="1642">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - darker_3.png"/>
 </tile>
 <tile id="1643">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - darker_4.png"/>
 </tile>
 <tile id="1644">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - darker_5.png"/>
 </tile>
 <tile id="1645">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - darker_6.png"/>
 </tile>
 <tile id="1646">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - darker_7.png"/>
 </tile>
 <tile id="1647">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - darker_8.png"/>
 </tile>
 <tile id="1648">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - darker_9.png"/>
 </tile>
 <tile id="1649">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - darker_10.png"/>
 </tile>
 <tile id="1650">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - darker_11.png"/>
 </tile>
 <tile id="1651">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - darker_12.png"/>
 </tile>
 <tile id="1652">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - darker_13.png"/>
 </tile>
 <tile id="1653">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - darker_14.png"/>
 </tile>
 <tile id="1654">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - darker_15.png"/>
 </tile>
 <tile id="1655">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - darker_16.png"/>
 </tile>
 <tile id="1656">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - darker_17.png"/>
 </tile>
 <tile id="1657">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - darker_18.png"/>
 </tile>
 <tile id="1658">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - darker_19.png"/>
 </tile>
 <tile id="1659">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - darker_20.png"/>
 </tile>
 <tile id="1660">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - darker_21.png"/>
 </tile>
 <tile id="1661">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - lighter_0.png"/>
 </tile>
 <tile id="1662">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - lighter_1.png"/>
 </tile>
 <tile id="1663">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - lighter_2.png"/>
 </tile>
 <tile id="1664">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - lighter_3.png"/>
 </tile>
 <tile id="1665">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - lighter_4.png"/>
 </tile>
 <tile id="1666">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - lighter_5.png"/>
 </tile>
 <tile id="1667">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - lighter_6.png"/>
 </tile>
 <tile id="1668">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - lighter_7.png"/>
 </tile>
 <tile id="1669">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - lighter_8.png"/>
 </tile>
 <tile id="1670">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - lighter_9.png"/>
 </tile>
 <tile id="1671">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - lighter_10.png"/>
 </tile>
 <tile id="1672">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - lighter_11.png"/>
 </tile>
 <tile id="1673">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - lighter_12.png"/>
 </tile>
 <tile id="1674">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - lighter_13.png"/>
 </tile>
 <tile id="1675">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - lighter_14.png"/>
 </tile>
 <tile id="1676">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - lighter_15.png"/>
 </tile>
 <tile id="1677">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - lighter_16.png"/>
 </tile>
 <tile id="1678">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - lighter_17.png"/>
 </tile>
 <tile id="1679">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - lighter_18.png"/>
 </tile>
 <tile id="1680">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - lighter_19.png"/>
 </tile>
 <tile id="1681">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - lighter_20.png"/>
 </tile>
 <tile id="1682">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/grass as sprites - lighter_21.png"/>
 </tile>
 <tile id="1683">
  <image width="448" height="320" source="../../Props/Atlas-Props-individual sprites/house_0.png"/>
 </tile>
 <tile id="1684">
  <image width="448" height="320" source="../../Props/Atlas-Props-individual sprites/house_1.png"/>
 </tile>
 <tile id="1685">
  <image width="128" height="64" source="../../Props/Atlas-Props-individual sprites/house_detail1.png"/>
 </tile>
 <tile id="1686">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/house-stairs.png"/>
 </tile>
 <tile id="1687">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/house-stairs-grass.png"/>
 </tile>
 <tile id="1688">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/lamp post - with lamp_0.png"/>
 </tile>
 <tile id="1689">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/lamp post - with lamp_1.png"/>
 </tile>
 <tile id="1690">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/lamp post - with lamp_2.png"/>
 </tile>
 <tile id="1691">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/lamp post - with lamp_3.png"/>
 </tile>
 <tile id="1692">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/lamp post - with lamp_4.png"/>
 </tile>
 <tile id="1693">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/lamp post - with lamp_5.png"/>
 </tile>
 <tile id="1694">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/lamp post - with lamp_6.png"/>
 </tile>
 <tile id="1695">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/lamp post - with lamp_7.png"/>
 </tile>
 <tile id="1696">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/lamp post - with lamp_8.png"/>
 </tile>
 <tile id="1697">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/lamp post - with lamp_9.png"/>
 </tile>
 <tile id="1698">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/lamp post - with lamp_10.png"/>
 </tile>
 <tile id="1699">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/lamp post - with lamp_11.png"/>
 </tile>
 <tile id="1700">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/lamp post -no lamp_0.png"/>
 </tile>
 <tile id="1701">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/lamp post -no lamp_1.png"/>
 </tile>
 <tile id="1702">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/lamp post -no lamp_2.png"/>
 </tile>
 <tile id="1703">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/lamp post -no lamp_3.png"/>
 </tile>
 <tile id="1704">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/lamp post -no lamp_4.png"/>
 </tile>
 <tile id="1705">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/lamp post -no lamp_5.png"/>
 </tile>
 <tile id="1706">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/lamp post -no lamp_6.png"/>
 </tile>
 <tile id="1707">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/lamp post -no lamp_7.png"/>
 </tile>
 <tile id="1708">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/lamp post -no lamp_8.png"/>
 </tile>
 <tile id="1709">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/lamp post -no lamp_9.png"/>
 </tile>
 <tile id="1710">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/lamp post -no lamp_10.png"/>
 </tile>
 <tile id="1711">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/lamp post -no lamp_11.png"/>
 </tile>
 <tile id="1712">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/medieval wooden wagon_0.png"/>
 </tile>
 <tile id="1713">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/medieval wooden wagon_1.png"/>
 </tile>
 <tile id="1714">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/medieval wooden wagon_2.png"/>
 </tile>
 <tile id="1715">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/medieval wooden wagon_3.png"/>
 </tile>
 <tile id="1716">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/mushrooms_0.png"/>
 </tile>
 <tile id="1717">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/mushrooms_1.png"/>
 </tile>
 <tile id="1718">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/mushrooms_2.png"/>
 </tile>
 <tile id="1719">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/mushrooms_3.png"/>
 </tile>
 <tile id="1720">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/mushrooms_4.png"/>
 </tile>
 <tile id="1721">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/mushrooms_5.png"/>
 </tile>
 <tile id="1722">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/mushrooms_6.png"/>
 </tile>
 <tile id="1723">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1__0.png"/>
 </tile>
 <tile id="1724">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1__1.png"/>
 </tile>
 <tile id="1725">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1__2.png"/>
 </tile>
 <tile id="1726">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1__3.png"/>
 </tile>
 <tile id="1727">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1__4.png"/>
 </tile>
 <tile id="1728">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1__5.png"/>
 </tile>
 <tile id="1729">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1__6.png"/>
 </tile>
 <tile id="1730">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1__7.png"/>
 </tile>
 <tile id="1731">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1__8.png"/>
 </tile>
 <tile id="1732">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1__9.png"/>
 </tile>
 <tile id="1733">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1__10.png"/>
 </tile>
 <tile id="1734">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1__11.png"/>
 </tile>
 <tile id="1735">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1__12.png"/>
 </tile>
 <tile id="1736">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1__13.png"/>
 </tile>
 <tile id="1737">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1__14.png"/>
 </tile>
 <tile id="1738">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1__15.png"/>
 </tile>
 <tile id="1739">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1__16.png"/>
 </tile>
 <tile id="1740">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1__17.png"/>
 </tile>
 <tile id="1741">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1__18.png"/>
 </tile>
 <tile id="1742">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1__19.png"/>
 </tile>
 <tile id="1743">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1__20.png"/>
 </tile>
 <tile id="1744">
  <image width="96" height="64" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1__21.png"/>
 </tile>
 <tile id="1745">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1-grass_0.png"/>
 </tile>
 <tile id="1746">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1-grass_1.png"/>
 </tile>
 <tile id="1747">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1-grass_2.png"/>
 </tile>
 <tile id="1748">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1-grass_3.png"/>
 </tile>
 <tile id="1749">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1-grass_4.png"/>
 </tile>
 <tile id="1750">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1-grass_5.png"/>
 </tile>
 <tile id="1751">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1-grass_6.png"/>
 </tile>
 <tile id="1752">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1-grass_7.png"/>
 </tile>
 <tile id="1753">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1-grass_8.png"/>
 </tile>
 <tile id="1754">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1-grass_9.png"/>
 </tile>
 <tile id="1755">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1-grass_10.png"/>
 </tile>
 <tile id="1756">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1-grass_11.png"/>
 </tile>
 <tile id="1757">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1-grass_12.png"/>
 </tile>
 <tile id="1758">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1-grass_13.png"/>
 </tile>
 <tile id="1759">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1-grass_14.png"/>
 </tile>
 <tile id="1760">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1-grass_15.png"/>
 </tile>
 <tile id="1761">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1-grass_16.png"/>
 </tile>
 <tile id="1762">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1-grass_17.png"/>
 </tile>
 <tile id="1763">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1-grass_18.png"/>
 </tile>
 <tile id="1764">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1-grass_19.png"/>
 </tile>
 <tile id="1765">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1-grass_20.png"/>
 </tile>
 <tile id="1766">
  <image width="96" height="64" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme1-grass_21.png"/>
 </tile>
 <tile id="1767">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2__0.png"/>
 </tile>
 <tile id="1768">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2__1.png"/>
 </tile>
 <tile id="1769">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2__2.png"/>
 </tile>
 <tile id="1770">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2__3.png"/>
 </tile>
 <tile id="1771">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2__4.png"/>
 </tile>
 <tile id="1772">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2__5.png"/>
 </tile>
 <tile id="1773">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2__6.png"/>
 </tile>
 <tile id="1774">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2__7.png"/>
 </tile>
 <tile id="1775">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2__8.png"/>
 </tile>
 <tile id="1776">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2__9.png"/>
 </tile>
 <tile id="1777">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2__10.png"/>
 </tile>
 <tile id="1778">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2__11.png"/>
 </tile>
 <tile id="1779">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2__12.png"/>
 </tile>
 <tile id="1780">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2__13.png"/>
 </tile>
 <tile id="1781">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2__14.png"/>
 </tile>
 <tile id="1782">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2__15.png"/>
 </tile>
 <tile id="1783">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2__16.png"/>
 </tile>
 <tile id="1784">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2__17.png"/>
 </tile>
 <tile id="1785">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2__18.png"/>
 </tile>
 <tile id="1786">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2__19.png"/>
 </tile>
 <tile id="1787">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2__20.png"/>
 </tile>
 <tile id="1788">
  <image width="96" height="64" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2__21.png"/>
 </tile>
 <tile id="1789">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2-grass_0.png"/>
 </tile>
 <tile id="1790">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2-grass_1.png"/>
 </tile>
 <tile id="1791">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2-grass_2.png"/>
 </tile>
 <tile id="1792">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2-grass_3.png"/>
 </tile>
 <tile id="1793">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2-grass_4.png"/>
 </tile>
 <tile id="1794">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2-grass_5.png"/>
 </tile>
 <tile id="1795">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2-grass_6.png"/>
 </tile>
 <tile id="1796">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2-grass_7.png"/>
 </tile>
 <tile id="1797">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2-grass_8.png"/>
 </tile>
 <tile id="1798">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2-grass_9.png"/>
 </tile>
 <tile id="1799">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2-grass_10.png"/>
 </tile>
 <tile id="1800">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2-grass_11.png"/>
 </tile>
 <tile id="1801">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2-grass_12.png"/>
 </tile>
 <tile id="1802">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2-grass_13.png"/>
 </tile>
 <tile id="1803">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2-grass_14.png"/>
 </tile>
 <tile id="1804">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2-grass_15.png"/>
 </tile>
 <tile id="1805">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2-grass_16.png"/>
 </tile>
 <tile id="1806">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2-grass_17.png"/>
 </tile>
 <tile id="1807">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2-grass_18.png"/>
 </tile>
 <tile id="1808">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2-grass_19.png"/>
 </tile>
 <tile id="1809">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2-grass_20.png"/>
 </tile>
 <tile id="1810">
  <image width="96" height="64" source="../../Props/Atlas-Props-individual sprites/rocks-color scheme2-grass_21.png"/>
 </tile>
 <tile id="1811">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/shrine_0.png"/>
 </tile>
 <tile id="1812">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/shrine_1.png"/>
 </tile>
 <tile id="1813">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/shrine_2.png"/>
 </tile>
 <tile id="1814">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/shrine_3.png"/>
 </tile>
 <tile id="1815">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/shrine_4.png"/>
 </tile>
 <tile id="1816">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/shrine_5.png"/>
 </tile>
 <tile id="1817">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/shrine_6.png"/>
 </tile>
 <tile id="1818">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/shrine_7.png"/>
 </tile>
 <tile id="1819">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/signs_0.png"/>
 </tile>
 <tile id="1820">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/signs_1.png"/>
 </tile>
 <tile id="1821">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/signs_2.png"/>
 </tile>
 <tile id="1822">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/signs_3.png"/>
 </tile>
 <tile id="1823">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/signs_4.png"/>
 </tile>
 <tile id="1824">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/signs_5.png"/>
 </tile>
 <tile id="1825">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/signs_6.png"/>
 </tile>
 <tile id="1826">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/signs_7.png"/>
 </tile>
 <tile id="1827">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/signs_8.png"/>
 </tile>
 <tile id="1828">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/signs_9.png"/>
 </tile>
 <tile id="1829">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/signs_10.png"/>
 </tile>
 <tile id="1830">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/signs_11.png"/>
 </tile>
 <tile id="1831">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/signs_12.png"/>
 </tile>
 <tile id="1832">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/signs_13.png"/>
 </tile>
 <tile id="1833">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/signs_14.png"/>
 </tile>
 <tile id="1834">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/signs_15.png"/>
 </tile>
 <tile id="1835">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/signs_16.png"/>
 </tile>
 <tile id="1836">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/signs_17.png"/>
 </tile>
 <tile id="1837">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/signs_18.png"/>
 </tile>
 <tile id="1838">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/signs_19.png"/>
 </tile>
 <tile id="1839">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/signs_20.png"/>
 </tile>
 <tile id="1840">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/signs_21.png"/>
 </tile>
 <tile id="1841">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/signs_22.png"/>
 </tile>
 <tile id="1842">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/signs_23.png"/>
 </tile>
 <tile id="1843">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/signs_24.png"/>
 </tile>
 <tile id="1844">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/signs_25.png"/>
 </tile>
 <tile id="1845">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/signs_26.png"/>
 </tile>
 <tile id="1846">
  <image width="32" height="64" source="../../Props/Atlas-Props-individual sprites/stone-halfsized walls-pillars_0.png"/>
 </tile>
 <tile id="1847">
  <image width="32" height="64" source="../../Props/Atlas-Props-individual sprites/stone-halfsized walls-pillars_1.png"/>
 </tile>
 <tile id="1848">
  <image width="32" height="64" source="../../Props/Atlas-Props-individual sprites/stone-halfsized walls-pillars_2.png"/>
 </tile>
 <tile id="1849">
  <image width="32" height="64" source="../../Props/Atlas-Props-individual sprites/stone-halfsized walls-pillars_3.png"/>
 </tile>
 <tile id="1850">
  <image width="32" height="64" source="../../Props/Atlas-Props-individual sprites/stone-halfsized walls-pillars_4.png"/>
 </tile>
 <tile id="1851">
  <image width="32" height="64" source="../../Props/Atlas-Props-individual sprites/stone-halfsized walls-pillars_5.png"/>
 </tile>
 <tile id="1852">
  <image width="32" height="64" source="../../Props/Atlas-Props-individual sprites/stone-halfsized walls-pillars_6.png"/>
 </tile>
 <tile id="1853">
  <image width="32" height="64" source="../../Props/Atlas-Props-individual sprites/stone-halfsized walls-pillars_7.png"/>
 </tile>
 <tile id="1854">
  <image width="32" height="64" source="../../Props/Atlas-Props-individual sprites/stone-halfsized walls-pillars_8.png"/>
 </tile>
 <tile id="1855">
  <image width="32" height="64" source="../../Props/Atlas-Props-individual sprites/stone-halfsized walls-pillars_9.png"/>
 </tile>
 <tile id="1856">
  <image width="32" height="64" source="../../Props/Atlas-Props-individual sprites/stone-halfsized walls-pillars_10.png"/>
 </tile>
 <tile id="1857">
  <image width="32" height="64" source="../../Props/Atlas-Props-individual sprites/stone-halfsized walls-pillars_11.png"/>
 </tile>
 <tile id="1858">
  <image width="32" height="64" source="../../Props/Atlas-Props-individual sprites/stone-halfsized walls-pillars_12.png"/>
 </tile>
 <tile id="1859">
  <image width="32" height="64" source="../../Props/Atlas-Props-individual sprites/stone-halfsized walls-pillars_13.png"/>
 </tile>
 <tile id="1860">
  <image width="32" height="64" source="../../Props/Atlas-Props-individual sprites/stone-halfsized walls-pillars_14.png"/>
 </tile>
 <tile id="1861">
  <image width="32" height="64" source="../../Props/Atlas-Props-individual sprites/stone-halfsized walls-pillars_15.png"/>
 </tile>
 <tile id="1862">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/stone-halfsized walls-solo blocks_0.png"/>
 </tile>
 <tile id="1863">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/stone-halfsized walls-solo blocks_1.png"/>
 </tile>
 <tile id="1864">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/stone-halfsized walls-solo blocks_2.png"/>
 </tile>
 <tile id="1865">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/stone-halfsized walls-solo blocks_3.png"/>
 </tile>
 <tile id="1866">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/stone-halfsized walls-solo blocks_4.png"/>
 </tile>
 <tile id="1867">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/stone-halfsized walls-solo blocks_5.png"/>
 </tile>
 <tile id="1868">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/stone-halfsized walls-solo blocks_6.png"/>
 </tile>
 <tile id="1869">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/stone-halfsized walls-solo blocks_7.png"/>
 </tile>
 <tile id="1870">
  <image width="32" height="32" source="../../Props/Atlas-Props-individual sprites/stone-halfsized walls-solo blocks_8.png"/>
 </tile>
 <tile id="1871">
  <image width="96" height="160" source="../../Props/Atlas-Props-individual sprites/stone-paths and stairs_0.png"/>
 </tile>
 <tile id="1872">
  <image width="160" height="128" source="../../Props/Atlas-Props-individual sprites/stone-paths and stairs_1.png"/>
 </tile>
 <tile id="1873">
  <image width="160" height="96" source="../../Props/Atlas-Props-individual sprites/stone-paths and stairs_2.png"/>
 </tile>
 <tile id="1874">
  <image width="96" height="96" source="../../Props/Atlas-Props-individual sprites/stone-paths and stairs_3.png"/>
 </tile>
 <tile id="1875">
  <image width="96" height="96" source="../../Props/Atlas-Props-individual sprites/stone-paths and stairs_4.png"/>
 </tile>
 <tile id="1876">
  <image width="96" height="96" source="../../Props/Atlas-Props-individual sprites/stone-paths and stairs_5.png"/>
 </tile>
 <tile id="1877">
  <image width="160" height="96" source="../../Props/Atlas-Props-individual sprites/stone-paths and stairs_6.png"/>
 </tile>
 <tile id="1878">
  <image width="96" height="192" source="../../Props/Atlas-Props-individual sprites/Trees - whole and trunks_0.png"/>
 </tile>
 <tile id="1879">
  <image width="96" height="192" source="../../Props/Atlas-Props-individual sprites/Trees - whole and trunks_1.png"/>
 </tile>
 <tile id="1880">
  <image width="96" height="64" source="../../Props/Atlas-Props-individual sprites/Trees - whole and trunks_2.png"/>
 </tile>
 <tile id="1881">
  <image width="96" height="64" source="../../Props/Atlas-Props-individual sprites/Trees - whole and trunks_3.png"/>
 </tile>
 <tile id="1882">
  <image width="96" height="64" source="../../Props/Atlas-Props-individual sprites/Trees - whole and trunks_4.png"/>
 </tile>
 <tile id="1883">
  <image width="96" height="64" source="../../Props/Atlas-Props-individual sprites/Trees - whole and trunks_5.png"/>
 </tile>
 <tile id="1884">
  <image width="96" height="64" source="../../Props/Atlas-Props-individual sprites/Trees - whole and trunks_6.png"/>
 </tile>
 <tile id="1885">
  <image width="96" height="64" source="../../Props/Atlas-Props-individual sprites/Trees - whole and trunks_7.png"/>
 </tile>
 <tile id="1886">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/trunks_0.png"/>
 </tile>
 <tile id="1887">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/trunks_1.png"/>
 </tile>
 <tile id="1888">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/trunks_2.png"/>
 </tile>
 <tile id="1889">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/trunks_3.png"/>
 </tile>
 <tile id="1890">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/trunks_4.png"/>
 </tile>
 <tile id="1891">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/trunks2__0.png"/>
 </tile>
 <tile id="1892">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/trunks2__1.png"/>
 </tile>
 <tile id="1893">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/trunks2__2.png"/>
 </tile>
 <tile id="1894">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/trunks2__3.png"/>
 </tile>
 <tile id="1895">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/trunks2__4.png"/>
 </tile>
 <tile id="1896">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/trunks2__6.png"/>
 </tile>
 <tile id="1897">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/trunks2__7.png"/>
 </tile>
 <tile id="1898">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/trunks2__9.png"/>
 </tile>
 <tile id="1899">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/trunks2__10.png"/>
 </tile>
 <tile id="1900">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/trunks2__11.png"/>
 </tile>
 <tile id="1901">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/trunks2__12.png"/>
 </tile>
 <tile id="1902">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/trunks2__13.png"/>
 </tile>
 <tile id="1903">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/trunks2__14.png"/>
 </tile>
 <tile id="1904">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/trunks2__15.png"/>
 </tile>
 <tile id="1905">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/trunks2__16.png"/>
 </tile>
 <tile id="1906">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/trunks2__17.png"/>
 </tile>
 <tile id="1907">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/trunks2__18.png"/>
 </tile>
 <tile id="1908">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/trunks2__19.png"/>
 </tile>
 <tile id="1909">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/trunks2__20.png"/>
 </tile>
 <tile id="1910">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/trunks2__21.png"/>
 </tile>
 <tile id="1911">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/trunks5__5.png"/>
 </tile>
 <tile id="1912">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/trunks8__8.png"/>
 </tile>
 <tile id="1913">
  <image width="96" height="128" source="../../Props/Atlas-Props-individual sprites/waterwell_0.png"/>
 </tile>
 <tile id="1914">
  <image width="96" height="128" source="../../Props/Atlas-Props-individual sprites/waterwell_1.png"/>
 </tile>
 <tile id="1915">
  <image width="128" height="192" source="../../Props/Atlas-Props-individual sprites/Animated Tree1_frame1.png"/>
  <animation>
   <frame tileid="1915" duration="100"/>
   <frame tileid="1916" duration="100"/>
   <frame tileid="1917" duration="100"/>
   <frame tileid="1918" duration="100"/>
   <frame tileid="1919" duration="100"/>
   <frame tileid="1920" duration="100"/>
   <frame tileid="1921" duration="100"/>
   <frame tileid="1922" duration="100"/>
  </animation>
 </tile>
 <tile id="1916">
  <image width="128" height="192" source="../../Props/Atlas-Props-individual sprites/Animated Tree1_frame2.png"/>
 </tile>
 <tile id="1917">
  <image width="128" height="192" source="../../Props/Atlas-Props-individual sprites/Animated Tree1_frame3.png"/>
 </tile>
 <tile id="1918">
  <image width="128" height="192" source="../../Props/Atlas-Props-individual sprites/Animated Tree1_frame4.png"/>
 </tile>
 <tile id="1919">
  <image width="128" height="192" source="../../Props/Atlas-Props-individual sprites/Animated Tree1_frame5.png"/>
 </tile>
 <tile id="1920">
  <image width="128" height="192" source="../../Props/Atlas-Props-individual sprites/Animated Tree1_frame6.png"/>
 </tile>
 <tile id="1921">
  <image width="128" height="192" source="../../Props/Atlas-Props-individual sprites/Animated Tree1_frame7.png"/>
 </tile>
 <tile id="1922">
  <image width="128" height="192" source="../../Props/Atlas-Props-individual sprites/Animated Tree1_frame8.png"/>
 </tile>
 <tile id="1923">
  <image width="128" height="192" source="../../Props/Atlas-Props-individual sprites/Animated Tree2_frame1.png"/>
  <animation>
   <frame tileid="1923" duration="100"/>
   <frame tileid="1924" duration="100"/>
   <frame tileid="1925" duration="100"/>
   <frame tileid="1926" duration="100"/>
   <frame tileid="1927" duration="100"/>
   <frame tileid="1928" duration="100"/>
   <frame tileid="1929" duration="100"/>
   <frame tileid="1930" duration="100"/>
  </animation>
 </tile>
 <tile id="1924">
  <image width="128" height="192" source="../../Props/Atlas-Props-individual sprites/Animated Tree2_frame2.png"/>
 </tile>
 <tile id="1925">
  <image width="128" height="192" source="../../Props/Atlas-Props-individual sprites/Animated Tree2_frame3.png"/>
 </tile>
 <tile id="1926">
  <image width="128" height="192" source="../../Props/Atlas-Props-individual sprites/Animated Tree2_frame4.png"/>
 </tile>
 <tile id="1927">
  <image width="128" height="192" source="../../Props/Atlas-Props-individual sprites/Animated Tree2_frame5.png"/>
 </tile>
 <tile id="1928">
  <image width="128" height="192" source="../../Props/Atlas-Props-individual sprites/Animated Tree2_frame6.png"/>
 </tile>
 <tile id="1929">
  <image width="128" height="192" source="../../Props/Atlas-Props-individual sprites/Animated Tree2_frame7.png"/>
 </tile>
 <tile id="1930">
  <image width="128" height="192" source="../../Props/Atlas-Props-individual sprites/Animated Tree2_frame8.png"/>
 </tile>
 <tile id="1931">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/anvil-shine_frame1.png"/>
  <animation>
   <frame tileid="1931" duration="100"/>
   <frame tileid="1932" duration="100"/>
   <frame tileid="1933" duration="100"/>
   <frame tileid="1934" duration="100"/>
   <frame tileid="1935" duration="100"/>
   <frame tileid="1936" duration="100"/>
  </animation>
 </tile>
 <tile id="1932">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/anvil-shine_frame2.png"/>
 </tile>
 <tile id="1933">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/anvil-shine_frame3.png"/>
 </tile>
 <tile id="1934">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/anvil-shine_frame4.png"/>
 </tile>
 <tile id="1935">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/anvil-shine_frame5.png"/>
 </tile>
 <tile id="1936">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/anvil-shine_frame6.png"/>
 </tile>
 <tile id="1937">
  <image width="32" height="36" source="../../Props/Atlas-Props-individual sprites/blacksmith sign_frame1.png"/>
  <animation>
   <frame tileid="1937" duration="100"/>
   <frame tileid="1938" duration="100"/>
   <frame tileid="1939" duration="100"/>
   <frame tileid="1940" duration="100"/>
   <frame tileid="1941" duration="100"/>
   <frame tileid="1942" duration="100"/>
   <frame tileid="1943" duration="100"/>
   <frame tileid="1944" duration="100"/>
   <frame tileid="1945" duration="100"/>
   <frame tileid="1946" duration="100"/>
   <frame tileid="1947" duration="100"/>
   <frame tileid="1948" duration="100"/>
   <frame tileid="1949" duration="100"/>
   <frame tileid="1950" duration="100"/>
   <frame tileid="1951" duration="100"/>
   <frame tileid="1952" duration="100"/>
  </animation>
 </tile>
 <tile id="1938">
  <image width="32" height="36" source="../../Props/Atlas-Props-individual sprites/blacksmith sign_frame2.png"/>
 </tile>
 <tile id="1939">
  <image width="32" height="36" source="../../Props/Atlas-Props-individual sprites/blacksmith sign_frame3.png"/>
 </tile>
 <tile id="1940">
  <image width="32" height="36" source="../../Props/Atlas-Props-individual sprites/blacksmith sign_frame4.png"/>
 </tile>
 <tile id="1941">
  <image width="32" height="36" source="../../Props/Atlas-Props-individual sprites/blacksmith sign_frame5.png"/>
 </tile>
 <tile id="1942">
  <image width="32" height="36" source="../../Props/Atlas-Props-individual sprites/blacksmith sign_frame6.png"/>
 </tile>
 <tile id="1943">
  <image width="32" height="36" source="../../Props/Atlas-Props-individual sprites/blacksmith sign_frame7.png"/>
 </tile>
 <tile id="1944">
  <image width="32" height="36" source="../../Props/Atlas-Props-individual sprites/blacksmith sign_frame8.png"/>
 </tile>
 <tile id="1945">
  <image width="32" height="36" source="../../Props/Atlas-Props-individual sprites/blacksmith sign_frame9.png"/>
 </tile>
 <tile id="1946">
  <image width="32" height="36" source="../../Props/Atlas-Props-individual sprites/blacksmith sign_frame10.png"/>
 </tile>
 <tile id="1947">
  <image width="32" height="36" source="../../Props/Atlas-Props-individual sprites/blacksmith sign_frame11.png"/>
 </tile>
 <tile id="1948">
  <image width="32" height="36" source="../../Props/Atlas-Props-individual sprites/blacksmith sign_frame12.png"/>
 </tile>
 <tile id="1949">
  <image width="32" height="36" source="../../Props/Atlas-Props-individual sprites/blacksmith sign_frame13.png"/>
 </tile>
 <tile id="1950">
  <image width="32" height="36" source="../../Props/Atlas-Props-individual sprites/blacksmith sign_frame14.png"/>
 </tile>
 <tile id="1951">
  <image width="32" height="36" source="../../Props/Atlas-Props-individual sprites/blacksmith sign_frame15.png"/>
 </tile>
 <tile id="1952">
  <image width="32" height="36" source="../../Props/Atlas-Props-individual sprites/blacksmith sign_frame16.png"/>
 </tile>
 <tile id="1953">
  <image width="128" height="128" source="../../Props/Atlas-Props-individual sprites/campfire1_frame1.png"/>
  <animation>
   <frame tileid="1953" duration="100"/>
   <frame tileid="1954" duration="100"/>
   <frame tileid="1955" duration="100"/>
   <frame tileid="1956" duration="100"/>
   <frame tileid="1957" duration="100"/>
   <frame tileid="1958" duration="100"/>
   <frame tileid="1959" duration="100"/>
   <frame tileid="1960" duration="100"/>
  </animation>
 </tile>
 <tile id="1954">
  <image width="128" height="128" source="../../Props/Atlas-Props-individual sprites/campfire1_frame2.png"/>
 </tile>
 <tile id="1955">
  <image width="128" height="128" source="../../Props/Atlas-Props-individual sprites/campfire1_frame3.png"/>
 </tile>
 <tile id="1956">
  <image width="128" height="128" source="../../Props/Atlas-Props-individual sprites/campfire1_frame4.png"/>
 </tile>
 <tile id="1957">
  <image width="128" height="128" source="../../Props/Atlas-Props-individual sprites/campfire1_frame5.png"/>
 </tile>
 <tile id="1958">
  <image width="128" height="128" source="../../Props/Atlas-Props-individual sprites/campfire1_frame6.png"/>
 </tile>
 <tile id="1959">
  <image width="128" height="128" source="../../Props/Atlas-Props-individual sprites/campfire1_frame7.png"/>
 </tile>
 <tile id="1960">
  <image width="128" height="128" source="../../Props/Atlas-Props-individual sprites/campfire1_frame8.png"/>
 </tile>
 <tile id="1961">
  <image width="128" height="128" source="../../Props/Atlas-Props-individual sprites/campfire2_frame1.png"/>
  <animation>
   <frame tileid="1961" duration="100"/>
   <frame tileid="1962" duration="100"/>
   <frame tileid="1963" duration="100"/>
   <frame tileid="1964" duration="100"/>
   <frame tileid="1965" duration="100"/>
   <frame tileid="1966" duration="100"/>
   <frame tileid="1967" duration="100"/>
   <frame tileid="1968" duration="100"/>
  </animation>
 </tile>
 <tile id="1962">
  <image width="128" height="128" source="../../Props/Atlas-Props-individual sprites/campfire2_frame2.png"/>
 </tile>
 <tile id="1963">
  <image width="128" height="128" source="../../Props/Atlas-Props-individual sprites/campfire2_frame3.png"/>
 </tile>
 <tile id="1964">
  <image width="128" height="128" source="../../Props/Atlas-Props-individual sprites/campfire2_frame4.png"/>
 </tile>
 <tile id="1965">
  <image width="128" height="128" source="../../Props/Atlas-Props-individual sprites/campfire2_frame5.png"/>
 </tile>
 <tile id="1966">
  <image width="128" height="128" source="../../Props/Atlas-Props-individual sprites/campfire2_frame6.png"/>
 </tile>
 <tile id="1967">
  <image width="128" height="128" source="../../Props/Atlas-Props-individual sprites/campfire2_frame7.png"/>
 </tile>
 <tile id="1968">
  <image width="128" height="128" source="../../Props/Atlas-Props-individual sprites/campfire2_frame8.png"/>
 </tile>
 <tile id="1969">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chest-closing_frame1.png"/>
  <animation>
   <frame tileid="1969" duration="100"/>
   <frame tileid="1970" duration="100"/>
   <frame tileid="1971" duration="100"/>
   <frame tileid="1972" duration="100"/>
   <frame tileid="1973" duration="100"/>
   <frame tileid="1974" duration="100"/>
   <frame tileid="1975" duration="100"/>
   <frame tileid="1976" duration="100"/>
   <frame tileid="1977" duration="100"/>
   <frame tileid="1978" duration="100"/>
   <frame tileid="1979" duration="100"/>
  </animation>
 </tile>
 <tile id="1970">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chest-closing_frame2.png"/>
 </tile>
 <tile id="1971">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chest-closing_frame3.png"/>
 </tile>
 <tile id="1972">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chest-closing_frame4.png"/>
 </tile>
 <tile id="1973">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chest-closing_frame5.png"/>
 </tile>
 <tile id="1974">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chest-closing_frame6.png"/>
 </tile>
 <tile id="1975">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chest-closing_frame7.png"/>
 </tile>
 <tile id="1976">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chest-closing_frame8.png"/>
 </tile>
 <tile id="1977">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chest-closing_frame9.png"/>
 </tile>
 <tile id="1978">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chest-closing_frame10.png"/>
 </tile>
 <tile id="1979">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chest-closing_frame11.png"/>
 </tile>
 <tile id="1980">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chest-opening1_frame1.png"/>
  <animation>
   <frame tileid="1980" duration="100"/>
   <frame tileid="1981" duration="100"/>
   <frame tileid="1982" duration="100"/>
   <frame tileid="1983" duration="100"/>
   <frame tileid="1984" duration="100"/>
   <frame tileid="1985" duration="100"/>
   <frame tileid="1986" duration="100"/>
   <frame tileid="1987" duration="100"/>
   <frame tileid="1988" duration="100"/>
   <frame tileid="1989" duration="100"/>
   <frame tileid="1990" duration="100"/>
   <frame tileid="1991" duration="100"/>
   <frame tileid="1992" duration="100"/>
  </animation>
 </tile>
 <tile id="1981">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chest-opening1_frame2.png"/>
 </tile>
 <tile id="1982">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chest-opening1_frame3.png"/>
 </tile>
 <tile id="1983">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chest-opening1_frame4.png"/>
 </tile>
 <tile id="1984">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chest-opening1_frame5.png"/>
 </tile>
 <tile id="1985">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chest-opening1_frame6.png"/>
 </tile>
 <tile id="1986">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chest-opening1_frame7.png"/>
 </tile>
 <tile id="1987">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chest-opening1_frame8.png"/>
 </tile>
 <tile id="1988">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chest-opening1_frame9.png"/>
 </tile>
 <tile id="1989">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chest-opening1_frame10.png"/>
 </tile>
 <tile id="1990">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chest-opening1_frame11.png"/>
 </tile>
 <tile id="1991">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chest-opening1_frame12.png"/>
 </tile>
 <tile id="1992">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chest-opening1_frame13.png"/>
 </tile>
 <tile id="1993">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chest-opening2_frame1.png"/>
  <animation>
   <frame tileid="1993" duration="100"/>
   <frame tileid="1994" duration="100"/>
   <frame tileid="1995" duration="100"/>
   <frame tileid="1996" duration="100"/>
   <frame tileid="1997" duration="100"/>
   <frame tileid="1998" duration="100"/>
   <frame tileid="1999" duration="100"/>
   <frame tileid="2000" duration="100"/>
   <frame tileid="2001" duration="100"/>
   <frame tileid="2002" duration="100"/>
   <frame tileid="2003" duration="100"/>
   <frame tileid="2004" duration="100"/>
   <frame tileid="2005" duration="100"/>
   <frame tileid="2006" duration="100"/>
  </animation>
 </tile>
 <tile id="1994">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chest-opening2_frame2.png"/>
 </tile>
 <tile id="1995">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chest-opening2_frame3.png"/>
 </tile>
 <tile id="1996">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chest-opening2_frame4.png"/>
 </tile>
 <tile id="1997">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chest-opening2_frame5.png"/>
 </tile>
 <tile id="1998">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chest-opening2_frame6.png"/>
 </tile>
 <tile id="1999">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chest-opening2_frame7.png"/>
 </tile>
 <tile id="2000">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chest-opening2_frame8.png"/>
 </tile>
 <tile id="2001">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chest-opening2_frame9.png"/>
 </tile>
 <tile id="2002">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chest-opening2_frame10.png"/>
 </tile>
 <tile id="2003">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chest-opening2_frame11.png"/>
 </tile>
 <tile id="2004">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chest-opening2_frame12.png"/>
 </tile>
 <tile id="2005">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chest-opening2_frame13.png"/>
 </tile>
 <tile id="2006">
  <image width="64" height="64" source="../../Props/Atlas-Props-individual sprites/chest-opening2_frame14.png"/>
 </tile>
 <tile id="2007">
  <image width="96" height="96" source="../../Props/Atlas-Props-individual sprites/door1-opening_frame1.png"/>
  <animation>
   <frame tileid="2007" duration="100"/>
   <frame tileid="2008" duration="100"/>
   <frame tileid="2009" duration="100"/>
   <frame tileid="2010" duration="100"/>
   <frame tileid="2011" duration="100"/>
   <frame tileid="2012" duration="100"/>
   <frame tileid="2013" duration="100"/>
   <frame tileid="2014" duration="100"/>
   <frame tileid="2015" duration="100"/>
   <frame tileid="2016" duration="100"/>
   <frame tileid="2017" duration="100"/>
   <frame tileid="2018" duration="100"/>
  </animation>
 </tile>
 <tile id="2008">
  <image width="96" height="96" source="../../Props/Atlas-Props-individual sprites/door1-opening_frame2.png"/>
 </tile>
 <tile id="2009">
  <image width="96" height="96" source="../../Props/Atlas-Props-individual sprites/door1-opening_frame3.png"/>
 </tile>
 <tile id="2010">
  <image width="96" height="96" source="../../Props/Atlas-Props-individual sprites/door1-opening_frame4.png"/>
 </tile>
 <tile id="2011">
  <image width="96" height="96" source="../../Props/Atlas-Props-individual sprites/door1-opening_frame5.png"/>
 </tile>
 <tile id="2012">
  <image width="96" height="96" source="../../Props/Atlas-Props-individual sprites/door1-opening_frame6.png"/>
 </tile>
 <tile id="2013">
  <image width="96" height="96" source="../../Props/Atlas-Props-individual sprites/door1-opening_frame7.png"/>
 </tile>
 <tile id="2014">
  <image width="96" height="96" source="../../Props/Atlas-Props-individual sprites/door1-opening_frame8.png"/>
 </tile>
 <tile id="2015">
  <image width="96" height="96" source="../../Props/Atlas-Props-individual sprites/door1-opening_frame9.png"/>
 </tile>
 <tile id="2016">
  <image width="96" height="96" source="../../Props/Atlas-Props-individual sprites/door1-opening_frame10.png"/>
 </tile>
 <tile id="2017">
  <image width="96" height="96" source="../../Props/Atlas-Props-individual sprites/door1-opening_frame11.png"/>
 </tile>
 <tile id="2018">
  <image width="96" height="96" source="../../Props/Atlas-Props-individual sprites/door1-opening_frame12.png"/>
 </tile>
 <tile id="2019">
  <image width="96" height="96" source="../../Props/Atlas-Props-individual sprites/door2-opening_frame1.png"/>
  <animation>
   <frame tileid="2019" duration="100"/>
   <frame tileid="2020" duration="100"/>
   <frame tileid="2021" duration="100"/>
   <frame tileid="2022" duration="100"/>
   <frame tileid="2023" duration="100"/>
   <frame tileid="2024" duration="100"/>
   <frame tileid="2025" duration="100"/>
   <frame tileid="2026" duration="100"/>
   <frame tileid="2027" duration="100"/>
   <frame tileid="2028" duration="100"/>
   <frame tileid="2029" duration="100"/>
   <frame tileid="2030" duration="100"/>
   <frame tileid="2031" duration="100"/>
  </animation>
 </tile>
 <tile id="2020">
  <image width="96" height="96" source="../../Props/Atlas-Props-individual sprites/door2-opening_frame2.png"/>
 </tile>
 <tile id="2021">
  <image width="96" height="96" source="../../Props/Atlas-Props-individual sprites/door2-opening_frame3.png"/>
 </tile>
 <tile id="2022">
  <image width="96" height="96" source="../../Props/Atlas-Props-individual sprites/door2-opening_frame4.png"/>
 </tile>
 <tile id="2023">
  <image width="96" height="96" source="../../Props/Atlas-Props-individual sprites/door2-opening_frame5.png"/>
 </tile>
 <tile id="2024">
  <image width="96" height="96" source="../../Props/Atlas-Props-individual sprites/door2-opening_frame6.png"/>
 </tile>
 <tile id="2025">
  <image width="96" height="96" source="../../Props/Atlas-Props-individual sprites/door2-opening_frame7.png"/>
 </tile>
 <tile id="2026">
  <image width="96" height="96" source="../../Props/Atlas-Props-individual sprites/door2-opening_frame8.png"/>
 </tile>
 <tile id="2027">
  <image width="96" height="96" source="../../Props/Atlas-Props-individual sprites/door2-opening_frame9.png"/>
 </tile>
 <tile id="2028">
  <image width="96" height="96" source="../../Props/Atlas-Props-individual sprites/door2-opening_frame10.png"/>
 </tile>
 <tile id="2029">
  <image width="96" height="96" source="../../Props/Atlas-Props-individual sprites/door2-opening_frame11.png"/>
 </tile>
 <tile id="2030">
  <image width="96" height="96" source="../../Props/Atlas-Props-individual sprites/door2-opening_frame12.png"/>
 </tile>
 <tile id="2031">
  <image width="96" height="96" source="../../Props/Atlas-Props-individual sprites/door2-opening_frame13.png"/>
 </tile>
 <tile id="2032">
  <image width="64" height="82" source="../../Props/Atlas-Props-individual sprites/forge chimney-smoke1_frame1.png"/>
  <animation>
   <frame tileid="2032" duration="100"/>
   <frame tileid="2033" duration="100"/>
   <frame tileid="2034" duration="100"/>
   <frame tileid="2035" duration="100"/>
   <frame tileid="2036" duration="100"/>
   <frame tileid="2037" duration="100"/>
   <frame tileid="2038" duration="100"/>
   <frame tileid="2039" duration="100"/>
   <frame tileid="2040" duration="100"/>
   <frame tileid="2041" duration="100"/>
   <frame tileid="2042" duration="100"/>
   <frame tileid="2043" duration="100"/>
   <frame tileid="2044" duration="100"/>
   <frame tileid="2045" duration="100"/>
   <frame tileid="2046" duration="100"/>
   <frame tileid="2047" duration="100"/>
  </animation>
 </tile>
 <tile id="2033">
  <image width="64" height="82" source="../../Props/Atlas-Props-individual sprites/forge chimney-smoke1_frame2.png"/>
 </tile>
 <tile id="2034">
  <image width="64" height="82" source="../../Props/Atlas-Props-individual sprites/forge chimney-smoke1_frame3.png"/>
 </tile>
 <tile id="2035">
  <image width="64" height="82" source="../../Props/Atlas-Props-individual sprites/forge chimney-smoke1_frame4.png"/>
 </tile>
 <tile id="2036">
  <image width="64" height="82" source="../../Props/Atlas-Props-individual sprites/forge chimney-smoke1_frame5.png"/>
 </tile>
 <tile id="2037">
  <image width="64" height="82" source="../../Props/Atlas-Props-individual sprites/forge chimney-smoke1_frame6.png"/>
 </tile>
 <tile id="2038">
  <image width="64" height="82" source="../../Props/Atlas-Props-individual sprites/forge chimney-smoke1_frame7.png"/>
 </tile>
 <tile id="2039">
  <image width="64" height="82" source="../../Props/Atlas-Props-individual sprites/forge chimney-smoke1_frame8.png"/>
 </tile>
 <tile id="2040">
  <image width="64" height="82" source="../../Props/Atlas-Props-individual sprites/forge chimney-smoke1_frame9.png"/>
 </tile>
 <tile id="2041">
  <image width="64" height="82" source="../../Props/Atlas-Props-individual sprites/forge chimney-smoke1_frame10.png"/>
 </tile>
 <tile id="2042">
  <image width="64" height="82" source="../../Props/Atlas-Props-individual sprites/forge chimney-smoke1_frame11.png"/>
 </tile>
 <tile id="2043">
  <image width="64" height="82" source="../../Props/Atlas-Props-individual sprites/forge chimney-smoke1_frame12.png"/>
 </tile>
 <tile id="2044">
  <image width="64" height="82" source="../../Props/Atlas-Props-individual sprites/forge chimney-smoke1_frame13.png"/>
 </tile>
 <tile id="2045">
  <image width="64" height="82" source="../../Props/Atlas-Props-individual sprites/forge chimney-smoke1_frame14.png"/>
 </tile>
 <tile id="2046">
  <image width="64" height="82" source="../../Props/Atlas-Props-individual sprites/forge chimney-smoke1_frame15.png"/>
 </tile>
 <tile id="2047">
  <image width="64" height="82" source="../../Props/Atlas-Props-individual sprites/forge chimney-smoke1_frame16.png"/>
 </tile>
 <tile id="2048">
  <image width="64" height="82" source="../../Props/Atlas-Props-individual sprites/forge chimney-smoke2_frame1.png"/>
  <animation>
   <frame tileid="2048" duration="100"/>
   <frame tileid="2049" duration="100"/>
   <frame tileid="2050" duration="100"/>
   <frame tileid="2051" duration="100"/>
   <frame tileid="2052" duration="100"/>
   <frame tileid="2053" duration="100"/>
   <frame tileid="2054" duration="100"/>
   <frame tileid="2055" duration="100"/>
   <frame tileid="2056" duration="100"/>
   <frame tileid="2057" duration="100"/>
   <frame tileid="2058" duration="100"/>
   <frame tileid="2059" duration="100"/>
   <frame tileid="2060" duration="100"/>
   <frame tileid="2061" duration="100"/>
   <frame tileid="2062" duration="100"/>
   <frame tileid="2063" duration="100"/>
   <frame tileid="2064" duration="100"/>
   <frame tileid="2065" duration="100"/>
   <frame tileid="2066" duration="100"/>
   <frame tileid="2067" duration="100"/>
   <frame tileid="2068" duration="100"/>
  </animation>
 </tile>
 <tile id="2049">
  <image width="64" height="82" source="../../Props/Atlas-Props-individual sprites/forge chimney-smoke2_frame2.png"/>
 </tile>
 <tile id="2050">
  <image width="64" height="82" source="../../Props/Atlas-Props-individual sprites/forge chimney-smoke2_frame3.png"/>
 </tile>
 <tile id="2051">
  <image width="64" height="82" source="../../Props/Atlas-Props-individual sprites/forge chimney-smoke2_frame4.png"/>
 </tile>
 <tile id="2052">
  <image width="64" height="82" source="../../Props/Atlas-Props-individual sprites/forge chimney-smoke2_frame5.png"/>
 </tile>
 <tile id="2053">
  <image width="64" height="82" source="../../Props/Atlas-Props-individual sprites/forge chimney-smoke2_frame6.png"/>
 </tile>
 <tile id="2054">
  <image width="64" height="82" source="../../Props/Atlas-Props-individual sprites/forge chimney-smoke2_frame7.png"/>
 </tile>
 <tile id="2055">
  <image width="64" height="82" source="../../Props/Atlas-Props-individual sprites/forge chimney-smoke2_frame8.png"/>
 </tile>
 <tile id="2056">
  <image width="64" height="82" source="../../Props/Atlas-Props-individual sprites/forge chimney-smoke2_frame9.png"/>
 </tile>
 <tile id="2057">
  <image width="64" height="82" source="../../Props/Atlas-Props-individual sprites/forge chimney-smoke2_frame10.png"/>
 </tile>
 <tile id="2058">
  <image width="64" height="82" source="../../Props/Atlas-Props-individual sprites/forge chimney-smoke2_frame11.png"/>
 </tile>
 <tile id="2059">
  <image width="64" height="82" source="../../Props/Atlas-Props-individual sprites/forge chimney-smoke2_frame12.png"/>
 </tile>
 <tile id="2060">
  <image width="64" height="82" source="../../Props/Atlas-Props-individual sprites/forge chimney-smoke2_frame13.png"/>
 </tile>
 <tile id="2061">
  <image width="64" height="82" source="../../Props/Atlas-Props-individual sprites/forge chimney-smoke2_frame14.png"/>
 </tile>
 <tile id="2062">
  <image width="64" height="82" source="../../Props/Atlas-Props-individual sprites/forge chimney-smoke2_frame15.png"/>
 </tile>
 <tile id="2063">
  <image width="64" height="82" source="../../Props/Atlas-Props-individual sprites/forge chimney-smoke2_frame16.png"/>
 </tile>
 <tile id="2064">
  <image width="64" height="82" source="../../Props/Atlas-Props-individual sprites/forge chimney-smoke2_frame17.png"/>
 </tile>
 <tile id="2065">
  <image width="64" height="82" source="../../Props/Atlas-Props-individual sprites/forge chimney-smoke2_frame18.png"/>
 </tile>
 <tile id="2066">
  <image width="64" height="82" source="../../Props/Atlas-Props-individual sprites/forge chimney-smoke2_frame19.png"/>
 </tile>
 <tile id="2067">
  <image width="64" height="82" source="../../Props/Atlas-Props-individual sprites/forge chimney-smoke2_frame20.png"/>
 </tile>
 <tile id="2068">
  <image width="64" height="82" source="../../Props/Atlas-Props-individual sprites/forge chimney-smoke2_frame21.png"/>
 </tile>
 <tile id="2069">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/forge1-anim1_frame1.png"/>
  <animation>
   <frame tileid="2069" duration="100"/>
   <frame tileid="2070" duration="100"/>
   <frame tileid="2071" duration="100"/>
   <frame tileid="2072" duration="100"/>
   <frame tileid="2073" duration="100"/>
   <frame tileid="2074" duration="100"/>
   <frame tileid="2075" duration="100"/>
   <frame tileid="2076" duration="100"/>
  </animation>
 </tile>
 <tile id="2070">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/forge1-anim1_frame2.png"/>
 </tile>
 <tile id="2071">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/forge1-anim1_frame3.png"/>
 </tile>
 <tile id="2072">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/forge1-anim1_frame4.png"/>
 </tile>
 <tile id="2073">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/forge1-anim1_frame5.png"/>
 </tile>
 <tile id="2074">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/forge1-anim1_frame6.png"/>
 </tile>
 <tile id="2075">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/forge1-anim1_frame7.png"/>
 </tile>
 <tile id="2076">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/forge1-anim1_frame8.png"/>
 </tile>
 <tile id="2077">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/forge1-anim2_frame1.png"/>
  <animation>
   <frame tileid="2077" duration="100"/>
   <frame tileid="2078" duration="100"/>
   <frame tileid="2079" duration="100"/>
   <frame tileid="2080" duration="100"/>
   <frame tileid="2081" duration="100"/>
   <frame tileid="2082" duration="100"/>
   <frame tileid="2083" duration="100"/>
   <frame tileid="2084" duration="100"/>
  </animation>
 </tile>
 <tile id="2078">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/forge1-anim2_frame2.png"/>
 </tile>
 <tile id="2079">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/forge1-anim2_frame3.png"/>
 </tile>
 <tile id="2080">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/forge1-anim2_frame4.png"/>
 </tile>
 <tile id="2081">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/forge1-anim2_frame5.png"/>
 </tile>
 <tile id="2082">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/forge1-anim2_frame6.png"/>
 </tile>
 <tile id="2083">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/forge1-anim2_frame7.png"/>
 </tile>
 <tile id="2084">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/forge1-anim2_frame8.png"/>
 </tile>
 <tile id="2085">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/forge2-anim1_frame1.png"/>
  <animation>
   <frame tileid="2085" duration="100"/>
   <frame tileid="2086" duration="100"/>
   <frame tileid="2087" duration="100"/>
   <frame tileid="2088" duration="100"/>
   <frame tileid="2089" duration="100"/>
   <frame tileid="2090" duration="100"/>
   <frame tileid="2091" duration="100"/>
   <frame tileid="2092" duration="100"/>
  </animation>
 </tile>
 <tile id="2086">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/forge2-anim1_frame2.png"/>
 </tile>
 <tile id="2087">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/forge2-anim1_frame3.png"/>
 </tile>
 <tile id="2088">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/forge2-anim1_frame4.png"/>
 </tile>
 <tile id="2089">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/forge2-anim1_frame5.png"/>
 </tile>
 <tile id="2090">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/forge2-anim1_frame6.png"/>
 </tile>
 <tile id="2091">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/forge2-anim1_frame7.png"/>
 </tile>
 <tile id="2092">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/forge2-anim1_frame8.png"/>
 </tile>
 <tile id="2093">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/forge2-anim2_frame1.png"/>
  <animation>
   <frame tileid="2093" duration="100"/>
   <frame tileid="2094" duration="100"/>
   <frame tileid="2095" duration="100"/>
   <frame tileid="2096" duration="100"/>
   <frame tileid="2097" duration="100"/>
   <frame tileid="2098" duration="100"/>
   <frame tileid="2099" duration="100"/>
   <frame tileid="2100" duration="100"/>
  </animation>
 </tile>
 <tile id="2094">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/forge2-anim2_frame2.png"/>
 </tile>
 <tile id="2095">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/forge2-anim2_frame3.png"/>
 </tile>
 <tile id="2096">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/forge2-anim2_frame4.png"/>
 </tile>
 <tile id="2097">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/forge2-anim2_frame5.png"/>
 </tile>
 <tile id="2098">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/forge2-anim2_frame6.png"/>
 </tile>
 <tile id="2099">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/forge2-anim2_frame7.png"/>
 </tile>
 <tile id="2100">
  <image width="64" height="96" source="../../Props/Atlas-Props-individual sprites/forge2-anim2_frame8.png"/>
 </tile>
 <tile id="2101">
  <image width="64" height="99" source="../../Props/Atlas-Props-individual sprites/shrines-activating_frame1.png"/>
  <animation>
   <frame tileid="2101" duration="100"/>
   <frame tileid="2102" duration="100"/>
   <frame tileid="2103" duration="100"/>
   <frame tileid="2104" duration="100"/>
   <frame tileid="2105" duration="100"/>
   <frame tileid="2106" duration="100"/>
   <frame tileid="2107" duration="100"/>
   <frame tileid="2108" duration="100"/>
   <frame tileid="2109" duration="100"/>
   <frame tileid="2110" duration="100"/>
   <frame tileid="2111" duration="100"/>
   <frame tileid="2112" duration="100"/>
   <frame tileid="2113" duration="100"/>
   <frame tileid="2114" duration="100"/>
  </animation>
 </tile>
 <tile id="2102">
  <image width="64" height="99" source="../../Props/Atlas-Props-individual sprites/shrines-activating_frame2.png"/>
 </tile>
 <tile id="2103">
  <image width="64" height="99" source="../../Props/Atlas-Props-individual sprites/shrines-activating_frame3.png"/>
 </tile>
 <tile id="2104">
  <image width="64" height="99" source="../../Props/Atlas-Props-individual sprites/shrines-activating_frame4.png"/>
 </tile>
 <tile id="2105">
  <image width="64" height="99" source="../../Props/Atlas-Props-individual sprites/shrines-activating_frame5.png"/>
 </tile>
 <tile id="2106">
  <image width="64" height="99" source="../../Props/Atlas-Props-individual sprites/shrines-activating_frame6.png"/>
 </tile>
 <tile id="2107">
  <image width="64" height="99" source="../../Props/Atlas-Props-individual sprites/shrines-activating_frame7.png"/>
 </tile>
 <tile id="2108">
  <image width="64" height="99" source="../../Props/Atlas-Props-individual sprites/shrines-activating_frame8.png"/>
 </tile>
 <tile id="2109">
  <image width="64" height="99" source="../../Props/Atlas-Props-individual sprites/shrines-activating_frame9.png"/>
 </tile>
 <tile id="2110">
  <image width="64" height="99" source="../../Props/Atlas-Props-individual sprites/shrines-activating_frame10.png"/>
 </tile>
 <tile id="2111">
  <image width="64" height="99" source="../../Props/Atlas-Props-individual sprites/shrines-activating_frame11.png"/>
 </tile>
 <tile id="2112">
  <image width="64" height="99" source="../../Props/Atlas-Props-individual sprites/shrines-activating_frame12.png"/>
 </tile>
 <tile id="2113">
  <image width="64" height="99" source="../../Props/Atlas-Props-individual sprites/shrines-activating_frame13.png"/>
 </tile>
 <tile id="2114">
  <image width="64" height="99" source="../../Props/Atlas-Props-individual sprites/shrines-activating_frame14.png"/>
 </tile>
 <tile id="2115">
  <image width="64" height="99" source="../../Props/Atlas-Props-individual sprites/shrines-available_frame1.png"/>
  <animation>
   <frame tileid="2115" duration="100"/>
   <frame tileid="2116" duration="100"/>
   <frame tileid="2117" duration="100"/>
   <frame tileid="2118" duration="100"/>
   <frame tileid="2119" duration="100"/>
   <frame tileid="2120" duration="100"/>
   <frame tileid="2121" duration="100"/>
   <frame tileid="2122" duration="100"/>
   <frame tileid="2123" duration="100"/>
   <frame tileid="2124" duration="100"/>
   <frame tileid="2125" duration="100"/>
   <frame tileid="2126" duration="100"/>
   <frame tileid="2127" duration="100"/>
   <frame tileid="2128" duration="100"/>
  </animation>
 </tile>
 <tile id="2116">
  <image width="64" height="99" source="../../Props/Atlas-Props-individual sprites/shrines-available_frame2.png"/>
 </tile>
 <tile id="2117">
  <image width="64" height="99" source="../../Props/Atlas-Props-individual sprites/shrines-available_frame3.png"/>
 </tile>
 <tile id="2118">
  <image width="64" height="99" source="../../Props/Atlas-Props-individual sprites/shrines-available_frame4.png"/>
 </tile>
 <tile id="2119">
  <image width="64" height="99" source="../../Props/Atlas-Props-individual sprites/shrines-available_frame5.png"/>
 </tile>
 <tile id="2120">
  <image width="64" height="99" source="../../Props/Atlas-Props-individual sprites/shrines-available_frame6.png"/>
 </tile>
 <tile id="2121">
  <image width="64" height="99" source="../../Props/Atlas-Props-individual sprites/shrines-available_frame7.png"/>
 </tile>
 <tile id="2122">
  <image width="64" height="99" source="../../Props/Atlas-Props-individual sprites/shrines-available_frame8.png"/>
 </tile>
 <tile id="2123">
  <image width="64" height="99" source="../../Props/Atlas-Props-individual sprites/shrines-available_frame9.png"/>
 </tile>
 <tile id="2124">
  <image width="64" height="99" source="../../Props/Atlas-Props-individual sprites/shrines-available_frame10.png"/>
 </tile>
 <tile id="2125">
  <image width="64" height="99" source="../../Props/Atlas-Props-individual sprites/shrines-available_frame11.png"/>
 </tile>
 <tile id="2126">
  <image width="64" height="99" source="../../Props/Atlas-Props-individual sprites/shrines-available_frame12.png"/>
 </tile>
 <tile id="2127">
  <image width="64" height="99" source="../../Props/Atlas-Props-individual sprites/shrines-available_frame13.png"/>
 </tile>
 <tile id="2128">
  <image width="64" height="99" source="../../Props/Atlas-Props-individual sprites/shrines-available_frame14.png"/>
 </tile>
 <tile id="2129">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/sword sharpener_frame1.png"/>
  <animation>
   <frame tileid="2129" duration="100"/>
   <frame tileid="2130" duration="100"/>
   <frame tileid="2131" duration="100"/>
   <frame tileid="2132" duration="100"/>
  </animation>
 </tile>
 <tile id="2130">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/sword sharpener_frame2.png"/>
 </tile>
 <tile id="2131">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/sword sharpener_frame3.png"/>
 </tile>
 <tile id="2132">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/sword sharpener_frame4.png"/>
 </tile>
 <tile id="2133">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/water deposit_frame1.png"/>
  <animation>
   <frame tileid="2133" duration="100"/>
   <frame tileid="2134" duration="100"/>
   <frame tileid="2135" duration="100"/>
   <frame tileid="2136" duration="100"/>
   <frame tileid="2137" duration="100"/>
   <frame tileid="2138" duration="100"/>
   <frame tileid="2139" duration="100"/>
   <frame tileid="2140" duration="100"/>
  </animation>
 </tile>
 <tile id="2134">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/water deposit_frame2.png"/>
 </tile>
 <tile id="2135">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/water deposit_frame3.png"/>
 </tile>
 <tile id="2136">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/water deposit_frame4.png"/>
 </tile>
 <tile id="2137">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/water deposit_frame5.png"/>
 </tile>
 <tile id="2138">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/water deposit_frame6.png"/>
 </tile>
 <tile id="2139">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/water deposit_frame7.png"/>
 </tile>
 <tile id="2140">
  <image width="64" height="32" source="../../Props/Atlas-Props-individual sprites/water deposit_frame8.png"/>
 </tile>
 <tile id="2141">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_empty_frame1.png"/>
  <animation>
   <frame tileid="2141" duration="100"/>
   <frame tileid="2142" duration="100"/>
   <frame tileid="2143" duration="100"/>
   <frame tileid="2144" duration="100"/>
   <frame tileid="2145" duration="100"/>
   <frame tileid="2146" duration="100"/>
   <frame tileid="2147" duration="100"/>
   <frame tileid="2148" duration="100"/>
   <frame tileid="2149" duration="100"/>
   <frame tileid="2150" duration="100"/>
   <frame tileid="2151" duration="100"/>
   <frame tileid="2152" duration="100"/>
   <frame tileid="2153" duration="100"/>
   <frame tileid="2154" duration="100"/>
   <frame tileid="2155" duration="100"/>
   <frame tileid="2156" duration="100"/>
   <frame tileid="2157" duration="100"/>
   <frame tileid="2158" duration="100"/>
   <frame tileid="2159" duration="100"/>
   <frame tileid="2160" duration="100"/>
   <frame tileid="2161" duration="100"/>
   <frame tileid="2162" duration="100"/>
   <frame tileid="2163" duration="100"/>
   <frame tileid="2164" duration="100"/>
   <frame tileid="2165" duration="100"/>
   <frame tileid="2166" duration="100"/>
   <frame tileid="2167" duration="100"/>
   <frame tileid="2168" duration="100"/>
   <frame tileid="2169" duration="100"/>
  </animation>
 </tile>
 <tile id="2142">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_empty_frame2.png"/>
 </tile>
 <tile id="2143">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_empty_frame3.png"/>
 </tile>
 <tile id="2144">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_empty_frame4.png"/>
 </tile>
 <tile id="2145">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_empty_frame5.png"/>
 </tile>
 <tile id="2146">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_empty_frame6.png"/>
 </tile>
 <tile id="2147">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_empty_frame7.png"/>
 </tile>
 <tile id="2148">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_empty_frame8.png"/>
 </tile>
 <tile id="2149">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_empty_frame9.png"/>
 </tile>
 <tile id="2150">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_empty_frame10.png"/>
 </tile>
 <tile id="2151">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_empty_frame11.png"/>
 </tile>
 <tile id="2152">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_empty_frame12.png"/>
 </tile>
 <tile id="2153">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_empty_frame13.png"/>
 </tile>
 <tile id="2154">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_empty_frame14.png"/>
 </tile>
 <tile id="2155">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_empty_frame15.png"/>
 </tile>
 <tile id="2156">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_empty_frame16.png"/>
 </tile>
 <tile id="2157">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_empty_frame17.png"/>
 </tile>
 <tile id="2158">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_empty_frame18.png"/>
 </tile>
 <tile id="2159">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_empty_frame19.png"/>
 </tile>
 <tile id="2160">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_empty_frame20.png"/>
 </tile>
 <tile id="2161">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_empty_frame21.png"/>
 </tile>
 <tile id="2162">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_empty_frame22.png"/>
 </tile>
 <tile id="2163">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_empty_frame23.png"/>
 </tile>
 <tile id="2164">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_empty_frame24.png"/>
 </tile>
 <tile id="2165">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_empty_frame25.png"/>
 </tile>
 <tile id="2166">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_empty_frame26.png"/>
 </tile>
 <tile id="2167">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_empty_frame27.png"/>
 </tile>
 <tile id="2168">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_empty_frame28.png"/>
 </tile>
 <tile id="2169">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_empty_frame29.png"/>
 </tile>
 <tile id="2170">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_empty_frame30.png"/>
  <animation>
   <frame tileid="2170" duration="100"/>
   <frame tileid="2171" duration="100"/>
   <frame tileid="2172" duration="100"/>
   <frame tileid="2173" duration="100"/>
   <frame tileid="2174" duration="100"/>
   <frame tileid="2175" duration="100"/>
   <frame tileid="2176" duration="100"/>
   <frame tileid="2177" duration="100"/>
   <frame tileid="2178" duration="100"/>
   <frame tileid="2179" duration="100"/>
   <frame tileid="2180" duration="100"/>
   <frame tileid="2181" duration="100"/>
   <frame tileid="2182" duration="100"/>
   <frame tileid="2183" duration="100"/>
   <frame tileid="2184" duration="100"/>
   <frame tileid="2185" duration="100"/>
   <frame tileid="2186" duration="100"/>
   <frame tileid="2187" duration="100"/>
   <frame tileid="2188" duration="100"/>
   <frame tileid="2189" duration="100"/>
   <frame tileid="2190" duration="100"/>
   <frame tileid="2191" duration="100"/>
   <frame tileid="2192" duration="100"/>
   <frame tileid="2193" duration="100"/>
   <frame tileid="2194" duration="100"/>
   <frame tileid="2195" duration="100"/>
   <frame tileid="2196" duration="100"/>
   <frame tileid="2197" duration="100"/>
   <frame tileid="2198" duration="100"/>
   <frame tileid="2199" duration="100"/>
  </animation>
 </tile>
 <tile id="2171">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_water_frame1.png"/>
 </tile>
 <tile id="2172">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_water_frame2.png"/>
 </tile>
 <tile id="2173">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_water_frame3.png"/>
 </tile>
 <tile id="2174">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_water_frame4.png"/>
 </tile>
 <tile id="2175">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_water_frame5.png"/>
 </tile>
 <tile id="2176">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_water_frame6.png"/>
 </tile>
 <tile id="2177">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_water_frame7.png"/>
 </tile>
 <tile id="2178">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_water_frame8.png"/>
 </tile>
 <tile id="2179">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_water_frame9.png"/>
 </tile>
 <tile id="2180">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_water_frame10.png"/>
 </tile>
 <tile id="2181">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_water_frame11.png"/>
 </tile>
 <tile id="2182">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_water_frame12.png"/>
 </tile>
 <tile id="2183">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_water_frame13.png"/>
 </tile>
 <tile id="2184">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_water_frame14.png"/>
 </tile>
 <tile id="2185">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_water_frame15.png"/>
 </tile>
 <tile id="2186">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_water_frame16.png"/>
 </tile>
 <tile id="2187">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_water_frame17.png"/>
 </tile>
 <tile id="2188">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_water_frame18.png"/>
 </tile>
 <tile id="2189">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_water_frame19.png"/>
 </tile>
 <tile id="2190">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_water_frame20.png"/>
 </tile>
 <tile id="2191">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_water_frame21.png"/>
 </tile>
 <tile id="2192">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_water_frame22.png"/>
 </tile>
 <tile id="2193">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_water_frame23.png"/>
 </tile>
 <tile id="2194">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_water_frame24.png"/>
 </tile>
 <tile id="2195">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_water_frame25.png"/>
 </tile>
 <tile id="2196">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_water_frame26.png"/>
 </tile>
 <tile id="2197">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_water_frame27.png"/>
 </tile>
 <tile id="2198">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_water_frame28.png"/>
 </tile>
 <tile id="2199">
  <image width="128" height="160" source="../../Props/Atlas-Props-individual sprites/water well_water_frame29.png"/>
 </tile>
</tileset>
